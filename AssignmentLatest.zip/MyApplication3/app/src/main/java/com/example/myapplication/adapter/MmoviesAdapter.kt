package com.example.myapplication.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.AbsListView.RecyclerListener
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding
import com.bumptech.glide.Glide
import com.example.myapplication.databinding.ItemMoviesBinding
import com.example.myapplication.models.Data

class MmoviesAdapter(val list: MutableList<Data>,val context:Context) : RecyclerView.Adapter<MmoviesAdapter.MoviesViewHolder>() {
 class MoviesViewHolder(val binding:ViewBinding): RecyclerView.ViewHolder(binding.root)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MoviesViewHolder {
     val view=ItemMoviesBinding.inflate(LayoutInflater.from(parent.context),parent,false)
       val moviesViewHolder =  MoviesViewHolder(view)
       return moviesViewHolder
    }

    override fun onBindViewHolder(holder: MoviesViewHolder, position: Int) {
       with(holder) {
          val result = list.get(position)
          (this.binding as ItemMoviesBinding).movieTitle.text = result.original_title
          this.binding.movieRating.text = result.vote_average
          this.binding.movieDesc.text = result.overview

           Glide.with(context).load("https://image.tmdb.org/t/p/original"+result.poster_path).into(binding.movieImg);
       }
    }
    override fun getItemCount(): Int {
       return list.size
    }
}
