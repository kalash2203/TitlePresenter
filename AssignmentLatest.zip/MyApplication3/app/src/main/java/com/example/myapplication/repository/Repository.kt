package com.example.myapplication.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.myapplication.network.RetrofitBuilder
import com.example.myapplication.models.Movies

class Repository {
    private val _moviesRecordResponse=MutableLiveData<Movies>()
   val moviesRecordResponse: LiveData<Movies>
   get()= _moviesRecordResponse
    suspend fun getmoviesRecord()
    {
        val result=RetrofitBuilder.getRetrofitBuilder().getApi().moviesRecord()
        if (result.isSuccessful && result.body() != null) {
            _moviesRecordResponse.postValue((result.body()))
        }
    }
}