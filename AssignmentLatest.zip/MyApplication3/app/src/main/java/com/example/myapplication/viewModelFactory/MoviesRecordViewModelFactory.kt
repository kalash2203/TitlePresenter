package com.example.myapplication.viewModelFactory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.repository.Repository
import com.example.myapplication.viewmodel.MoviesRecordViewModel

class MoviesRecordViewModelFactory
    (private val repository: Repository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
return MoviesRecordViewModel(repository) as T
    }
}