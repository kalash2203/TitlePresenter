package com.example.myapplication.models

data class Movies(
    val page:Int,
    val total_pages:Int,
    val total_results:Int,
    val results:MutableList<Data> = arrayListOf()


)
data class Data(
 val poster_path:String,
val overview:String,
val original_title:String,
val vote_average:String

)