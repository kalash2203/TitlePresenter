package com.example.myapplication.network

import com.example.myapplication.models.Movies
import com.example.myapplication.utils.Constants
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface APIs {
@GET("/3/movie/popular")
suspend fun moviesRecord(@Query("api_key")api_key:String=Constants.API_KEY): Response<Movies>
}