package com.example.myapplication.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.viewbinding.ViewBinding
import com.example.myapplication.R
import com.example.myapplication.adapter.MmoviesAdapter
import com.example.myapplication.databinding.FragmentPopularMoviesBinding
import com.example.myapplication.repository.Repository
import com.example.myapplication.viewModelFactory.MoviesRecordViewModelFactory
import com.example.myapplication.viewmodel.MoviesRecordViewModel

class PopularMoviesFragment : Fragment() {
lateinit var popularMoviesBinding:FragmentPopularMoviesBinding
val repository=Repository()
val viewModelFactory = MoviesRecordViewModelFactory(repository )
val viewModel by viewModels<MoviesRecordViewModel> {
    viewModelFactory
}

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        popularMoviesBinding=FragmentPopularMoviesBinding.inflate(layoutInflater)
        viewModel.mmoviesRecord()
viewModel.movieLiveData.observe(viewLifecycleOwner, Observer {
    val moviesAdapter=MmoviesAdapter(it.results,requireContext())
    popularMoviesBinding.recyclerView.adapter=moviesAdapter
})






        return popularMoviesBinding.root
    }
}