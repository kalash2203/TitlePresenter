package com.example.myapplication.utils

object Constants {
    const val BASE_URL="https://api.themoviedb.org"
    const val API_KEY ="eea99fe7c928ecdd1b58949e5f5cc9b9"
}