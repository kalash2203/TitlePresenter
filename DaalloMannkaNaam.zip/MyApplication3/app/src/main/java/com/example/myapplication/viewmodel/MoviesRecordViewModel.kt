package com.example.myapplication.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.models.Movies
import com.example.myapplication.repository.Repository
import kotlinx.coroutines.launch

class MoviesRecordViewModel (val repo:Repository):ViewModel()
{
    val movieLiveData: LiveData<Movies>
    get()=repo.moviesRecordResponse
    fun mmoviesRecord()
    {
        viewModelScope.launch {
            repo.getmoviesRecord()
        }
    }
}